import greenfoot.*;

/**
 * Write a description of class Q1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Q1 extends World
{

    /**
     * Constructor for objects of class Q1.
     * 
     */
    public Q1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(913, 515, 1); 
    }
     public void act() 
    {
    
    //if (Greenfoot.isKeyDown("left")   
    MouseInfo mouse = Greenfoot.getMouseInfo();
    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <825 && y > 320 && y < 420) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q1_C());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <850 && y > 200 && y < 300) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q1_B());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <750 && y > 100 && y < 200) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q1_A());
       }
     }    
    }
}