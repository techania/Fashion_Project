import greenfoot.*;

/**
 * Write a description of class Q4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Q4 extends World
{

    /**
     * Constructor for objects of class Q4.
     * 
     */
    public Q4()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(913, 515, 1); 
    }
     public void act() 
    {       
     MouseInfo mouse = Greenfoot.getMouseInfo();
    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <750 && y > 320 && y < 420) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q4_C());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <850 && y > 200 && y < 300) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q4_B());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <750 && y > 100 && y < 200) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q4_A());
       }
     }    
    }
}
