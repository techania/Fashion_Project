import greenfoot.*;

/**
 * Write a description of class Q7 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Q7 extends World
{

    /**
     * Constructor for objects of class Q7.
     * 
     */
    public Q7()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(913, 515, 1); 
    }
     public void act() 
    {
        
    //if (Greenfoot.isKeyDown("left"))
     MouseInfo mouse = Greenfoot.getMouseInfo();
    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <800 && y > 270 && y < 450) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q7_C());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <880 && y > 150 && y < 275) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q7_B());
       }
     }

    if (Greenfoot.mouseClicked(null)) {
        int x = mouse.getX();
        int y = mouse.getY();
        if ( x > 470 && x <900 && y > 50 && y < 150) {//min and max should be the edges of the area;
        Greenfoot.setWorld(new Q7_A());
       }
     }    
    }
}
