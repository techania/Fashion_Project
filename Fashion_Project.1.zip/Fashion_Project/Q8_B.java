import greenfoot.*;

/**
 * Write a description of class Q8_B here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Q8_B extends World
{

    /**
     * Constructor for objects of class Q8_B.
     * 
     */
    public Q8_B()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(913, 515, 1); 
    }
}
